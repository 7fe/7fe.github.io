using System;
using System.Drawing;

using System.Windows.Forms;

//using SetClipboardHelper;
/*
doskey csc=C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe $*

csc /out:Hello.exe Hello.cs

C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe
*/

public class Hello {
  public static void Main() {
    Console.WriteLine("Hello, World!");
  }
}