using System;
using Wolfram.NETLink;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

public class Example {
 [STAThread]
 public static void Main(String[] args) {
	MathKernel k = new MathKernel();
	k.Compute("ExportString[Graphics[Circle[]],{\"Base64\",\"PNG\"}, Background -> None]");
	byte[] bytes = Convert.FromBase64String(k.Result.ToString());	//File.WriteAllBytes("C:\\Users\\austin\\Desktop\\Clipboard\\output.png", bytes);
	Stream stream = new MemoryStream(bytes);
	//Clipboard.SetImage(Image.FromStream(stream));
	/*Bitmap bitmap = new Bitmap(stream);
	Clipboard.SetData(DataFormats.Bitmap, bitmap);*/
	IDataObject dataObject = new DataObject();
	dataObject.SetData("PNG", stream);
	Clipboard.SetDataObject(dataObject, true);	
	/*_Bitmap.Save(stream, ImageFormat.Png);
	var data = newDataObject("PNG", stream);
	Clipboard.Clear();
	Clipboard.SetDataObject(data, true);*/
	/*	
	using (Stream stream = new MemoryStream(bytes)){
		Bitmap bitmap = new Bitmap(stream);
		Clipboard.SetData(DataFormats.Bitmap, bitmap);
    }
	*/
  }
}