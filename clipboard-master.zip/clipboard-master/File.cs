using System;
using System.Drawing;

using System.Windows.Forms;

//using SetClipboardHelper;
/*
doskey csc=C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe $*

csc /out:Hello.exe Hello.cs

C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe
*/

public class File {
  public static void Main(String[] args){
    Console.WriteLine("Clipboard contains:Hello, clipboard");
	
	if(args.Length!=1)return;
	Console.WriteLine(args[0]);
	Console.WriteLine(System.Console.In.ReadToEnd());
	//new SetClipboardHelper( DataFormats.Text, "See, I'm on the clipboard" ).Go();
	//System.Windows.Forms.Clipboard.SetText("Hello, clipboard");
	/* 
	System.Windows.Forms.Clipboard.SetText("test");
	Bitmap b = new Bitmap("C:\\Users\\austin\\Desktop\\Clipboard\\test.png");
	b.MakeTransparent(
	  System.Windows.Forms.BackColor
	);
	pictureBox1.Image = b;
	Windows.Forms.Clipboard.SetDataObject(b); */
  }
}
