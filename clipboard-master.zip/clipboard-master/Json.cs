using System;
using Wolfram.NETLink;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

using Newtonsoft.Json;
/*
 csc /target:winexe /reference:Wolfram.NETLink.dll ExampleSimple.cs
 doskey csc=C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe $*
*/

public class Json {
  public static void Main(String[] args) {
    dynamic f = JsonConvert.DeserializeObject(System.Console.In.ReadToEnd());
    Console.WriteLine(f[0]);
  }
}