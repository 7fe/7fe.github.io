using System;
using Wolfram.NETLink;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

// csc /target:winexe /reference:Wolfram.NETLink.dll ExampleSimple.cs

public class ExampleSimple {
 [STAThread]
 public static void Main(String[] args) {
	//MathKernel k = new MathKernel();
	//k.Compute("ExportString[Graphics[Circle[]],{\"Base64\",\"PNG\"}, Background -> None]");
	//string input = k.Result.ToString();
	string input = System.Console.In.ReadToEnd();
	
	byte[] bytes = Convert.FromBase64String(input);	
	Stream stream = new MemoryStream(bytes);
	IDataObject dataObject = new DataObject();
	dataObject.SetData(args[0], stream);
	Clipboard.SetDataObject(dataObject, true);
	
	Image bmp = Clipboard.GetImage();
	if(bmp != null)
	  Console.WriteLine("true");
	return;

	/*Bitmap myImage = new Bitmap(stream);
	IDataObject dataObject = new DataObject();
	dataObject.SetData("BMP", stream);
	Clipboard.SetDataObject(dataobject);*/
	/*
	byte[] bytes = Convert.FromBase64String(input);	
	Stream stream = new MemoryStream(bytes);

	IDataObject dataObject = new DataObject();
	dataObject.SetData("CF_DIBV5", stream);
	Clipboard.SetDataObject(dataObject, true); */
  }
}