<div><?php

var_dump($_SERVER);
header_remove("X-Powered-By");
//header("X-Powered-By: ASP.NET");
class x implements ArrayAccess {
    public $this = array();
    public function __construct() {
        $this[0] = 1337;
        echo $this[0];
        var_dump($this);
        $this->this = array(
            "one"   => 1,
            "two"   => 2,
            "three" => 3,
        );
        return $this;
    }
    public function offsetSet($offset, $value) {
        if (is_null($offset)) {
            $this->this[] = $value;
        } else {
            $this->this[$offset] = $value;
        }
    }

    public function offsetExists($offset) {
        return isset($this->this[$offset]);
    }

    public function offsetUnset($offset) {
        unset($this->this[$offset]);
    }

    public function offsetGet($offset) {
        return isset($this->this[$offset]) ? $this->this[$offset] : null;
    }
    
    public function toArray(){
      return $this->this;
    }
    function __toString(){
      return "test";
    }
}
class y{
  /* public function __construct(){
    ;
  }
  public function toString(){
    return "x";
  } */
  public function __call($func, $argv){
    if (!is_callable($func) || substr($func, 0, 6) !== 'array_'){
      throw new BadMethodCallException(__CLASS__.'->'.$func);
    }
    return call_user_func_array($func, array_merge(array($this->getArrayCopy()), $argv));
  }
}
function x(){return new x();}
echo var_dump(x());
$str = urldecode($_SERVER[REQUEST_URI]);
echo mb_substr($str,1,mb_strlen($str)-1).'<br>';

echo mb_strlen("漢字😊").'<br>';
echo "漢字😊<br>";
$x=x();
echo var_dump(x()->toArray())."<br>";
echo var_dump([1,3,3])."<br>";
$a = [1,2,3];
echo var_dump($a[0]);
echo var_dump($x->{0});
echo var_dump($x[0]);
$x[0] = 1;
echo var_dump($x);
// x->split(....)->join(....)->x([1,2,3]);
$c = get_defined_functions();
var_dump($c);

/*array_filter($c,function($i){
  echo $i;
},ARRAY_FILTER_USE_KEY);*/
if(is_array($c['internal'])){
foreach($c['internal'] as $key=>$value){
  //if($value[0]=='m'&&$value[1]=='b')runkit_function_remove ($value);
}
}
function _strlen(){
  echo "strlen";
}
_strlen();
?> 

</div>
2h20 + co2 <-> 
